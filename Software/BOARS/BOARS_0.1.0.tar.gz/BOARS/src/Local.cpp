#include <Rcpp.h>

// [[Rcpp::export]]
Rcpp::LogicalMatrix local (const Rcpp::NumericMatrix & x){
  unsigned int outrows = x.nrow(), outcols = x.ncol(), i = 0;//, j = 0;
//  double d;
  Rcpp::LogicalMatrix out(outrows-1,outcols);
//  Rcpp::NumericMatrix out(outrows-1,outcols);
  Rcpp::NumericVector v1 = x.row(i);
  Rcpp::LogicalVector res = v1 <=  v1 ;

  for (i = 1; i < outrows ; i++){
//    for (j = i + 1; j < outrows ; j ++){
//      res = x.row(0)>x.row(i);
//      out.row(i-1) = res*res;
        out.row(i-1) = x.row(0)>x.row(i);
//      d = mean(res);
//      out(j,i)=1-d;
//      out(i,j)=d;
//    }
  }
  return out;
}


