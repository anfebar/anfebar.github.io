#include <Rcpp.h>


// [[Rcpp::export]]
Rcpp::NumericMatrix pairProb (const Rcpp::NumericMatrix & x){
  unsigned int outrows = x.nrow(), i = 0, j = 0;
  double d;
  Rcpp::NumericMatrix out(outrows,outrows);
  Rcpp::NumericVector v1 = x.row(i);
  Rcpp::LogicalVector res = v1 <=  v1 ;

  for (i = 0; i < outrows - 1; i++){
    for (j = i + 1; j < outrows ; j ++){
      res = x.row(i)>x.row(j);
      d = sum(res);
      out(j,i)=x.ncol()-d;
      out(i,j)=d;
    }
  }
  return out;
}


