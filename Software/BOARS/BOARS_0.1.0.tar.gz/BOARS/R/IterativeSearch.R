#####################################################
#####################################################
#library(Rcpp)

### Input
# mcmc.xi: Posterior sample
# Grid.alpha: grid for alpha
# local.error: grid for t
# Grid.gamma.local: grid for gamma
# global.error: grid for q

global_order = function(mcmc.xi, Grid.alpha,
                        local.error, Grid.gamma.local,
                        global.error, Pv_threshold)
{

#  library(progress)
#  requireNamespace(progress)
  ##########################
  # Setting delta
  ##########################

  Ndelta = max(c(length(Grid.alpha),length(local.error),
                 length(Grid.gamma.local),length(global.error)))


  Delta = sort(unique(c(ceiling(Ndelta*((c(40,20,10:1)/20))),1:5)), decreasing = T)

  Ngrid = prod(c(length(Grid.alpha),length(local.error),
                 length(Grid.gamma.local),length(global.error)))


  message("")

  ##########################
  # Computing fixed cost
  ##########################

  # Start the clock!
  ptm0 <- proc.time()

  ### Computing pairwise probabilities
  # We compute these probabilities by subsetting mcmc.xi.
  # Thus, we can keep track of the progress.
  M = 50 # Number of subsets
  N = floor(nrow(mcmc.xi)/M)
  U = (1:M)*(N)
  U[M] = nrow(mcmc.xi)
  L = c(1,U[-M]+1)
  Ind = cbind(L,U)
  W = ((U-L)+1)/nrow(mcmc.xi)

  pb <- progress_bar$new(format = "Computing pairwise probabilities [:bar] :percent in :elapsed",
                         total = nrow(Ind), clear = FALSE)

  pair0 = matrix(0, ncol = ncol(mcmc.xi), nrow = ncol(mcmc.xi))
  for(J in 1:M)
  {
    pair0 <- pair0 + pairProb(t(mcmc.xi[Ind[J,1]:Ind[J,2],,drop=FALSE]))
    pb$tick()
  }
  pair = pair0
  colnames(pair) = rownames(pair) = colnames(mcmc.xi)
  pair = ceiling(pair0)/nrow(mcmc.xi)
  colnames(pair) = rownames(pair) = colnames(mcmc.xi)


  ### Pairwise probabilities satisfying threshold alpha.
  f.alpha.pair = function(alpha)
  {
    alpha.pair = ifelse((pair > alpha) & (pair<(1-alpha)),NA,pair)
    diag(alpha.pair) = NA
    alpha.pair = ifelse(alpha.pair<=0.5,-1,1)

    pb$tick()
    Ind = !(colSums(is.na(alpha.pair))==ncol(alpha.pair))
    alpha.pair = alpha.pair[Ind,Ind,drop=F]
    alpha.pair
  }

  Grid.alpha = sort(Grid.alpha,decreasing = T)
  pb <- progress_bar$new(format = "Computing bounded probabilities  [:bar] :percent in :elapsed",
                         total = length(Grid.alpha), clear = FALSE)
  Alpha.pair = lapply(Grid.alpha,f.alpha.pair)


  if(sum(dim(Alpha.pair[[1]]))!=0)
  {
    ### Computing local statements
    f.local = function(J)
    {
      ### Computing local statements for each alpha
      pb$tick()
      alpha.pair = Alpha.pair[[1]]
      aux0 = mcmc.xi[,colnames(alpha.pair)[J]]
      aux1 = mcmc.xi[,colnames(alpha.pair)[!is.na(alpha.pair[J,])],drop=FALSE]
      aux3 = t(local(t(cbind(aux0,aux1))))
      colnames(aux3) = colnames(aux1)
      aux4 = alpha.pair[J,][!is.na(alpha.pair[J,])]>0
      aux5_0 = cbind(t(t(aux3)==aux4))

      J = rownames(alpha.pair)[J]

      f.local.alpha.tmp = function(JJ)
      {
        alpha.pair = Alpha.pair[[JJ]]
        if(sum(dim(alpha.pair))!=0)
        {
          if(sum(rownames(alpha.pair)==J)!=0)
          {
            out = colnames(aux5_0)%in%names(alpha.pair[J,])[!is.na(alpha.pair[J,])]
          }else{
            out = rep(NA,ncol(aux5_0))
          }
        }else{
          out = rep(NA,ncol(aux5_0))
        }
        out
      }

      aux4 = sapply(1:length(Grid.alpha),f.local.alpha.tmp)
      aux5 = aux5_0%*%aux4

      f.local.alpha = function(JJ)
      {
        alpha.pair = Alpha.pair[[JJ]]
        if(sum(dim(alpha.pair))!=0)
        {
          if(sum(rownames(alpha.pair)==J)!=0)
          {
            aux4 = alpha.pair[J,][!is.na(alpha.pair[J,])]>0
            aux6 = prop.table(table(aux5[,JJ]))
            out = list(param = J, statem = names(aux4), localprob = aux6, localcount = aux5[,JJ])
          }else{
            out = NA
          }
        }else{
          out = NA
        }
        out
      }

      lapply(1:length(Grid.alpha),f.local.alpha)
    }

    pb <- progress_bar$new(format = "Computing local statements       [:bar] :percent in :elapsed",
                           total = ncol(Alpha.pair[[1]]), clear = FALSE)
    system.time(localstatealpha <- lapply(1:ncol(Alpha.pair[[1]]),f.local))


    #########################
    # Iteration
    #########################
    OptGlobalIter = function(mcmc.xi, Grid.alpha, local.error, Grid.gamma.local,
                             global.error, Grid.alphaNext, Alpha.pair, localstatealpha,
                             print.option=0)
    {
      Grid.alphaNext = sort(Grid.alphaNext,decreasing = T)

      if(sum(dim(Alpha.pair[[1]]))!=0)
      {
        ### Computing global statement for each alpha, t, gamma, q.
        f.global.Grid_alpha = function(alpha)
        {
          alpha.pair = Alpha.pair[[which(Grid.alpha==alpha)]]
          if(sum(dim(alpha.pair))!=0)
          {
            localstate <- list()
            JJ=0
            for(J in 1:ncol(Alpha.pair[[1]]))
            {
              if(sum(is.na(localstatealpha[[J]][[which(Grid.alpha==alpha)]]))==0)
              {
                JJ = JJ+1
                localstate[[JJ]] = localstatealpha[[J]][[which(Grid.alpha==alpha)]]
              }
            }

            ### For given alpha, we compute global statement for each t, gamma, q
            f.global.Grid_t_gamma_q = function(Jgrid)
            {
              t.local = Grid[Jgrid,"t"]
              gamma.local = Grid[Jgrid,"gamma"]
              global.error = Grid[Jgrid,"q"]

              # Selecting meaningful local statements with probability>q
              f.ind.global = function(J)
              {
                aux0 = floor(length(localstate[[J]]$statem)*t.local)
                aux1 = as.numeric(names(localstate[[J]]$localprob))
                aux3 = sum(localstate[[J]]$localprob[aux1 >= length(localstate[[J]]$statem)-aux0])
                if(t.local>0) out = (aux0 >= 1) & (aux3 >= gamma.local)
                if(t.local==0) out = (aux3 >= gamma.local)
                out
              }
              Ind.global = which(sapply(1:length(localstate),f.ind.global))

              if(length(Ind.global)>0)
              {
                # Computing loss function
                f.prob.global = function(J)
                {
                  aux5 = floor(length(localstate[[J]]$statem)*t.local)
                  localstate[[J]]$localcount>= (length(localstate[[J]]$statem)-aux5)
                }
                system.time(global.count <- sapply(Ind.global,f.prob.global))

                P_v = mean(rowSums(global.count) >=
                             (ncol(global.count)-floor(ncol(global.count)*global.error))
                           )
                NG_v = ncol(global.count)
                qNG_v = floor(ncol(global.count)*global.error)
                NL_v = sapply(Ind.global,function(J) length(localstate[[J]]$statem))
                tNL_v =  NL_v*t.local#floor(NL_v*t.local)
                loss = log(NG_v-qNG_v)*(sum(NL_v)-sum(tNL_v))*P_v*(P_v>=Pv_threshold)
                #loss = (log(NG_v-qNG_v+1)+sum(log(NL_v-tNL_v+1)))*(P_v)
                out = data.frame(alpha=alpha, t = t.local,
                                 gamma = gamma.local, q = global.error,
                                 P_v = P_v, NG_v = NG_v, qNG_v = qNG_v,
                                 NL_v = mean(NL_v), tNL_v = mean(tNL_v),loss = loss)
              }else{
                out = data.frame(alpha=alpha, t = t.local,
                                 gamma = gamma.local, q = global.error,
                                 P_v = -1, NG_v = -1, qNG_v = -1,
                                 NL_v = -1, tNL_v = -1,loss = -1)
              }
              pb$tick()
              out
            }
            #pb <- progress_bar$new(total = ncol(alpha.pair))
            out1 = t(sapply(1:nrow(Grid),f.global.Grid_t_gamma_q))
          }else{
            for(j1 in 1:nrow(Grid)) pb$tick()
            out1 = data.frame(alpha=alpha, t = Grid[,"t"],
                              gamma = Grid[,"gamma"], q = Grid[,"q"],
                              P_v = -1, NG_v = -1, qNG_v = -1,
                              NL_v = -1, tNL_v = -1,loss = -1)
          }
          out1
        }

        Grid = cbind(t=sort(rep(local.error,length(Grid.gamma.local))),gamma=Grid.gamma.local)
        Grid = cbind(Grid[sort(rep(1:nrow(Grid),length(global.error))),,drop=F],q = global.error)

        if(print.option%in%c(0,2))
          pb <- progress_bar$new(format = "Evaluating grid                  [:bar] :percent in :elapsed",
                                 total = nrow(Grid)*length(Grid.alphaNext), clear = FALSE)
        if(print.option==1)
          pb <- progress_bar$new(format = "Finding initial point            [:bar] :percent in :elapsed",
                                 total = nrow(Grid)*length(Grid.alphaNext), clear = FALSE)
        output0 = lapply(Grid.alphaNext,f.global.Grid_alpha)

        output = output0[[1]]
        if(length(Grid.alphaNext)>1)
        {
          for(J in 2:length(Grid.alphaNext))
            output = rbind(output0[[J]],output)
        }

        tmp = rbind((sapply(1:ncol(output),function(j) simplify2array(output[,j]))))
        colnames(tmp) = colnames(output)
        output = data.frame(tmp)

        # Computing optimal global statement
        Optimal = data.frame(output[which.max(simplify2array(output[,"loss"])),])

      }else{
        Optimal = data.frame(alpha=-1, t = -1,
                             gamma = -1, q = -1,
                             P_v = -1, NG_v = -1, qNG_v = -1,
                             NL_v = -1, tNL_v = -1,loss = -1)
      }

      if(print.option%in%c(0,2))
      {
        if(print.option==0)
          message("Optimal global statement")
        print(Optimal)
      }

      ### Reporting optimal global statement
      if(Optimal$loss!=-1)
      {
        alpha = Optimal$alpha
        alpha.pair = Alpha.pair[[which(Grid.alpha==alpha)]]
        t.local = Optimal$t
        gamma.local = Optimal$gamma
        global.error = Optimal$q

        alpha.pair = Alpha.pair[[which(Grid.alpha==alpha)]]
        localstate <- list()
        JJ=0
        for(J in 1:ncol(Alpha.pair[[1]]))
        {
          if(sum(is.na(localstatealpha[[J]][[which(Grid.alpha==alpha)]]))==0)
          {
            JJ = JJ+1
            localstate[[JJ]] = localstatealpha[[J]][[which(Grid.alpha==alpha)]]
          }
        }

        # Selecting local statements
        f.ind.global = function(J)
        {
          aux0 = floor(length(localstate[[J]]$statem)*t.local)
          aux1 = as.numeric(names(localstate[[J]]$localprob))
          aux3 = sum(localstate[[J]]$localprob[aux1 >= length(localstate[[J]]$statem)-aux0])
          if(t.local>0) out = (aux0 >= 1) & (aux3 >= gamma.local)
          if(t.local==0) out = (aux3 >= gamma.local)
          out
        }
        Ind.global = which(sapply(1:length(localstate),f.ind.global))

        f.prob.global = function(J)
        {
          aux5 = floor(length(localstate[[J]]$statem)*t.local)
          localstate[[J]]$localcount>= (length(localstate[[J]]$statem)-aux5)
        }
        system.time(global.count <- sapply(Ind.global,f.prob.global))

        P_v = mean(rowSums(global.count) >=
                     (ncol(global.count)-floor(ncol(global.count)*global.error))
        )
        NG_v = ncol(global.count)
        qNG_v = floor(ncol(global.count)*global.error)
        NL_v = sapply(Ind.global,function(J) length(localstate[[J]]$statem))
        tNL_v =  NL_v*t.local#floor(NL_v*t.local)
        loss = log(NG_v-qNG_v)*(sum(NL_v)-sum(tNL_v))*P_v*(P_v>=Pv_threshold)
        #loss = (log(NG_v-qNG_v+1)+sum(log(NL_v-tNL_v+1)))*(P_v)
        out = data.frame(alpha=alpha, t = t.local,
                         gamma = gamma.local, q = global.error,
                         P_v = P_v, NG_v = NG_v, qNG_v = qNG_v,
                         NL_v = mean(NL_v), tNL_v = mean(tNL_v),loss = loss)
        out-Optimal

        f.global.statement = function(J)
        {
          localstate[[J]]$param
          localstate[[J]]$statem
          aux = alpha.pair[rownames(alpha.pair)==localstate[[J]]$param,colnames(alpha.pair)%in%localstate[[J]]$statem]
          Names = colnames(alpha.pair)[colnames(alpha.pair)%in%localstate[[J]]$statem]
          smaller = Names[aux==1]
          greater = Names[aux==-1]
          if(length(smaller)==0) smaller=NA
          if(length(greater)==0) greater=NA
          list(param=localstate[[J]]$param,smaller=smaller,greater=greater)
        }

        global.statement <- sapply(Ind.global,f.global.statement)

        # Stop the clock
        ptm1 <- proc.time() - ptm0
        message(paste("Total computation time:",round(ptm1[[3]]/60,1),"min"))

        invisible(list(Optimal=Optimal, global.statement = global.statement, grid.eval = output,
                       comp.time = round(ptm1[[3]]/60,1)))


      }else{
        # Stop the clock
        ptm1 <- proc.time() - ptm0
        if(print.option==0)
        {
          message(paste("Total computation time:",round(ptm1[[3]]/60,1),"min"))

          message("It's not possible to report a global statement for this grid.")
          message("Try with another grid")
        }
      }

    }
    #########################
    #########################
    if(Ngrid<=500)
    {
      if(Ngrid>1)
      {
        message("")
        message("#####################")
        message("# Optimization starts")
        message("#####################")
      }


      result = OptGlobalIter(mcmc.xi, Grid.alpha,
                             local.error,
                             Grid.gamma.local,
                             global.error,
                             Grid.alpha,
                             Alpha.pair, localstatealpha)

      Optimal0 = result$Optimal

    }else
    {
      message("")
      message("#########################")
      message("# Initializing algorithm")
      message("#########################")

      Grid.gamma.local = sort(Grid.gamma.local,decreasing=T)
      Grid.alpha = sort(Grid.alpha,decreasing=T)

      Indgamma = c(which.max(Grid.gamma.local),which.min(Grid.gamma.local))
      Indgamma = c(Indgamma,(1:length(Grid.gamma.local))[1:21*(length(Grid.gamma.local)/21)])

      Indalpha = c(which.max(Grid.alpha),which.min(Grid.alpha))
      Indalpha = c(Indalpha,(1:length(Grid.alpha))[1:21*(length(Grid.alpha)/21)])

      message("# Fixed initialization")
      result = OptGlobalIter(mcmc.xi, Grid.alpha = Grid.alpha,
                             local.error = max(local.error),
                             Grid.gamma.local = unique(Grid.gamma.local[Indgamma]),
                             global.error = max(global.error),
                             Grid.alphaNext = unique(Grid.alpha[Indalpha]),
                             Alpha.pair, localstatealpha, print.option = 1)

      message("# Random initialization")
      result1 = OptGlobalIter(mcmc.xi, Grid.alpha = Grid.alpha,
                             local.error = unique(sample(local.error,3,replace = T)),
                             Grid.gamma.local = unique(sample(Grid.gamma.local,3,replace = T)),
                             global.error = unique(sample(global.error,3,replace = T)),
                             Grid.alphaNext = unique(sample(Grid.alpha,3,replace = T)),
                             Alpha.pair, localstatealpha, print.option = 1)

      if(!is.null(result1$Optimal))
      {
        if(result1$Optimal$loss > result$Optimal$loss)
          result = result1
      }

      Optimal = result$Optimal

      z = 0

      stop_quietly <- function() {
        opt <- options(show.error.messages = FALSE)
        on.exit(options(opt))
        stop()
      }

      while(is.null(Optimal))
      {
        z = z+1
        if(z==100)
        {
          message("It was not possible to initialize the algorith. Try again!")
          stop_quietly()
        }
        result = OptGlobalIter(mcmc.xi, Grid.alpha = Grid.alpha,
                               local.error = unique(sample(local.error,3,replace = T)),
                               Grid.gamma.local = unique(sample(Grid.gamma.local,3,replace = T)),
                               global.error = unique(sample(global.error,3,replace = T)),
                               Grid.alphaNext = unique(sample(Grid.alpha,3,replace = T)),
                               Alpha.pair, localstatealpha, print.option = 1)

        Optimal = result$Optimal
      }

      OptimalIter = result$Optimal
      Optimal0 = Optimal
      Loss0 = Optimal$loss
      Loss = 0


      alpha = Optimal$alpha
      t.local = Optimal$t
      gamma.local = Optimal$gamma
      q.global = Optimal$q


      f.grid.next = function(current,Grid,delta)
      {
        aux = Grid[c(max(1,which(Grid==current)-delta),which(Grid==current),
                     min(length(Grid),which(Grid==current)+delta))]
        #if(sample(1:2,1)==1)sample(aux,2)
        aux
      }


      JDelta = 1

      message("")
      message("#####################")
      message("# Optimization starts")
      message("#####################")
      Iter = 0
      while(JDelta<=length(Delta))
      {
        Iter = Iter + 1
        delta = Delta[JDelta]
        ### Input
        Grid.alphaNext = unique(f.grid.next(alpha,Grid.alpha,delta))
        local.errorNext = unique(f.grid.next(t.local,local.error,delta))
        Grid.gamma.localNext = unique(f.grid.next(gamma.local,Grid.gamma.local,delta))
        global.errorNext = unique(f.grid.next(q.global,global.error,delta))

        f.print.delta = function(x)
        {
          x = sort(x, decreasing = T)
          z = c(2,1)
          if(length(x)==1) z = c(1,1)
          diff(x[z])
        }

        message("")
        message(paste("Iter ",Iter,"  (\u0394\u03B1,\u0394t,\u0394\u03B3,\u0394q) = (",
                      paste(round(c(
                        f.print.delta(Grid.alphaNext),
                        f.print.delta(local.errorNext),
                        f.print.delta(Grid.gamma.localNext),
                        f.print.delta(global.errorNext)
                      ),4), collapse = ", ")
                      , ")",
                      sep=""))
        message(paste("Ends at (\u0394\u03B1,\u0394t,\u0394\u03B3,\u0394q) = (",
                      paste(round(c(
                        f.print.delta(Grid.alpha),
                        f.print.delta(local.error),
                        f.print.delta(Grid.gamma.local),
                        f.print.delta(global.error)
                      ),4), collapse = ", ")
                      , ")",sep=""))


        result = OptGlobalIter(mcmc.xi, Grid.alpha,
                               local.errorNext,
                               Grid.gamma.localNext,
                               global.errorNext,
                               Grid.alphaNext,
                               Alpha.pair, localstatealpha,
                               print.option = 2)

        Optimal = result$Optimal
        Loss = Optimal$loss
        if(Loss==Loss0) JDelta = JDelta+1
        if(Loss>Loss0)
        {
          Optimal0 = Optimal
          Loss0 = Loss
          alpha = Optimal0$alpha
          t.local = Optimal0$t
          gamma.local = Optimal0$gamma
          q.global = Optimal0$q
        }
        #message(paste("Loss =",round(Loss0,4)))
        OptimalIter = rbind(OptimalIter,Optimal0)
      }


      message("")
      message("##########################")
      message("# Optimal global statement")
      message("##########################")
      print(Optimal0)
      ptm1 <- proc.time() - ptm0
      message(paste("Total computation time:",round(ptm1[[3]]/60,1),"min"))

      #ptm1 <- proc.time() - ptm0
      #message(paste("Total computation time:",round(ptm1[[3]]/60,1),"min"))
    }

    suppressMessages(result <- OptGlobalIter(mcmc.xi, Grid.alpha,
                                             Optimal0$t,
                                             Optimal0$gamma,
                                             Optimal0$q,
                                             Optimal0$alpha,
                                             Alpha.pair, localstatealpha,
                                             print.option = 1))

  }else{
    result = NULL

    # Stop the clock
    ptm1 <- proc.time() - ptm0
    message(paste("Total computation time:",round(ptm1[[3]]/60,1),"min"))

    message("It's not possible to report a global statement for this grid.")
    message("Try with another grid for alpha")
  }

  message("")
  if(!is.null(result)) invisible(result)
}

